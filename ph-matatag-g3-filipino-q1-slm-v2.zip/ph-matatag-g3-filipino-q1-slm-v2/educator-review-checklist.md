# Educator Review Checklist — Filipino G3 Q1 SLM v2

**Package:** `ph-matatag-g3-filipino-q1-slm-v2`  
**Status:** REQUIRES_EDUCATOR_REVIEW  
**Language:** Filipino (fil-PH)

## Per-lesson checks
For each of the 15 lessons:
- [ ] Competency code matches MELCs / source module
- [ ] Objective is age-appropriate for Grade 3
- [ ] All instructional language is correct Filipino
- [ ] Multiple-choice distractors are plausible, not shaming
- [ ] Matching pairs and sequences have unique unambiguous answers
- [ ] Assessment items sample the stated objective (not trivia)
- [ ] Stories/examples are culturally suitable and child-safe
- [ ] Passing threshold (4/5) is appropriate
- [ ] Accessibility alternatives are usable with TalkBack

## Pack-level
- [ ] No English placeholders remain
- [ ] No copied DepEd PDF illustrations
- [ ] No trademarked characters
- [ ] No cleartext NAS/local URLs
- [ ] Release status remains REQUIRES_EDUCATOR_REVIEW until signed off

## Sign-off
- Educator name: _______________
- Date: _______________
- Decision: APPROVE / REVISE
