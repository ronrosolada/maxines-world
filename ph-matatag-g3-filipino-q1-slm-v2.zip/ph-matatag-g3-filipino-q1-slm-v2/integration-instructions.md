# Integration Instructions — Filipino G3 Q1 SLM v2

## Package
- **ID:** `ph-matatag-g3-filipino-q1-slm-v2`
- **Version:** `0.2.0`
- **Lessons:** 15 (one per DepEd ADM Module 1–15)
- **Subject:** FILIPINO | Grade 3 | Quarter 1

## App path
Copy or merge `content-pack/lessons/*.json` into:
```
android/app/src/main/assets/content/ph-matatag/grade-3/filipino/module-NN/
```
Mapping: lesson `w01-d01` → module-01, `w01-d02` → module-02, ... through `w08-d01` → module-15.

Or load as a single modular pack if using ContentRepository bootstrap:
```
assets/content/bootstrap/ph-matatag-g3-filipino-q1-slm-v2/
```

## Capabilities used
ANIMATED_EXPLANATION_V1, MULTIPLE_CHOICE_V1, MATCHING_PAIRS_V1,
SEQUENCE_BUILDER_V1, SORT_AND_CLASSIFY_V1, HOTSPOT_IMAGE_V1

## Do not
- Do not mark `educatorValidated=true` without human educator sign-off
- Do not ship original SLM PDFs inside the APK
- Do not translate lesson content to English
